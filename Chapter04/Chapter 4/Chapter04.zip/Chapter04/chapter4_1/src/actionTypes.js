export const CREATE_POST = 'CREATE_POST'
export const EDIT_POST = 'EDIT_POST'
export const SET_FILTER = 'SET_FILTER'
